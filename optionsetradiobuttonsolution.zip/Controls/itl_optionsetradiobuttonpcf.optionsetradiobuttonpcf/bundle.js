/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./optionsetradiobuttonpcf/index.ts"
/*!******************************************!*\
  !*** ./optionsetradiobuttonpcf/index.ts ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   optionsetradiobuttonpcf: () => (/* binding */ optionsetradiobuttonpcf)\n/* harmony export */ });\nclass optionsetradiobuttonpcf {\n  /**\n   * Empty constructor.\n   */\n  constructor() {\n    this._selectedValue = undefined;\n    // Empty\n  }\n  /**\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\n   * Data-set values are not initialized here, use updateView.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\n   */\n  init(context, notifyOutputChanged, state, container) {\n    this._container = container;\n    this._notifyOutputChanged = notifyOutputChanged;\n  }\n  /**\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions\n   */\n  updateView(context) {\n    var _a, _b, _c, _d, _e, _f, _g;\n    this._container.innerHTML = \"\";\n    this._container.style.display = context.mode.isVisible ? \"\" : \"none\";\n    // Get showLabel value as text: show/hide\n    var showLabel = ((_b = (_a = context.parameters.showLabel) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : \"\").toString().toLowerCase() === \"show\";\n    var orientationValue = (_e = (_d = (_c = context.parameters.layoutOrientation) === null || _c === void 0 ? void 0 : _c.raw) === null || _d === void 0 ? void 0 : _d.toString().toLowerCase()) !== null && _e !== void 0 ? _e : \"horizontal\";\n    var isHorizontal = orientationValue !== \"vertical\";\n    var options = (_f = context.parameters.sampleProperty.attributes) === null || _f === void 0 ? void 0 : _f.Options;\n    var currentValue = context.parameters.sampleProperty.raw;\n    var isDisabled = context.mode.isControlDisabled;\n    this._selectedValue = currentValue === null ? undefined : currentValue;\n    if (!options || options.length === 0) {\n      var emptyMessage = document.createElement(\"div\");\n      emptyMessage.textContent = \"No option set metadata available.\";\n      this._container.appendChild(emptyMessage);\n      return;\n    }\n    var wrapper = document.createElement(\"div\");\n    wrapper.style.display = \"flex\";\n    wrapper.style.flexDirection = \"column\";\n    wrapper.style.gap = \"0.5rem\";\n    wrapper.style.width = \"100%\";\n    if (showLabel) {\n      var labelText = context.mode.label || ((_g = context.parameters.sampleProperty.attributes) === null || _g === void 0 ? void 0 : _g.DisplayName) || \"Options\";\n      if (labelText) {\n        var header = document.createElement(\"div\");\n        header.textContent = labelText;\n        header.style.fontWeight = \"600\";\n        header.style.fontSize = \"0.9rem\";\n        header.style.marginBottom = \"0.5rem\";\n        header.style.color = \"#333\";\n        wrapper.appendChild(header);\n      }\n    }\n    var optionsRow = document.createElement(\"div\");\n    optionsRow.style.display = \"flex\";\n    optionsRow.style.flexDirection = isHorizontal ? \"row\" : \"column\";\n    optionsRow.style.flexWrap = isHorizontal ? \"wrap\" : \"nowrap\";\n    optionsRow.style.alignItems = isHorizontal ? \"center\" : \"flex-start\";\n    optionsRow.style.justifyContent = \"flex-start\";\n    optionsRow.style.gap = \"0.75rem\";\n    optionsRow.style.width = \"100%\";\n    var groupName = \"optionset-radio-\".concat(Math.random().toString(36).slice(2));\n    options.forEach(option => {\n      var _a;\n      var optionId = \"option-\".concat(groupName, \"-\").concat(option.Value);\n      var optionLabel = (_a = option.Label) !== null && _a !== void 0 ? _a : option.Value.toString();\n      var optionWrapper = document.createElement(\"label\");\n      optionWrapper.style.display = \"inline-flex\";\n      optionWrapper.style.alignItems = \"center\";\n      optionWrapper.style.gap = \"0.4rem\";\n      optionWrapper.style.cursor = isDisabled ? \"default\" : \"pointer\";\n      optionWrapper.style.flex = isHorizontal ? \"0 1 auto\" : \"1 1 100%\";\n      optionWrapper.style.minWidth = isHorizontal ? \"120px\" : \"auto\";\n      optionWrapper.style.padding = \"0.15rem 0.35rem\";\n      optionWrapper.style.borderRadius = \"0.25rem\";\n      optionWrapper.style.backgroundColor = isDisabled ? \"#f9f9f9\" : \"transparent\";\n      var input = document.createElement(\"input\");\n      input.type = \"radio\";\n      input.name = groupName;\n      input.id = optionId;\n      input.value = option.Value.toString();\n      input.checked = currentValue === option.Value;\n      input.disabled = isDisabled;\n      input.setAttribute(\"aria-label\", optionLabel);\n      input.addEventListener(\"change\", () => {\n        if (!isDisabled && input.checked) {\n          this._selectedValue = option.Value;\n          this._notifyOutputChanged();\n        }\n      });\n      var span = document.createElement(\"span\");\n      span.textContent = optionLabel;\n      span.style.whiteSpace = \"nowrap\";\n      optionWrapper.appendChild(input);\n      optionWrapper.appendChild(span);\n      optionsRow.appendChild(optionWrapper);\n    });\n    wrapper.appendChild(optionsRow);\n    this._container.appendChild(wrapper);\n  }\n  /**\n   * It is called by the framework prior to a control receiving new data.\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\n   */\n  getOutputs() {\n    return {\n      sampleProperty: this._selectedValue\n    };\n  }\n  /**\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\n   */\n  destroy() {\n    this._container.innerHTML = \"\";\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./optionsetradiobuttonpcf/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./optionsetradiobuttonpcf/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('optionsetradiobuttonpcf.optionsetradiobuttonpcf', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.optionsetradiobuttonpcf);
} else {
	var optionsetradiobuttonpcf = optionsetradiobuttonpcf || {};
	optionsetradiobuttonpcf.optionsetradiobuttonpcf = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.optionsetradiobuttonpcf;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}